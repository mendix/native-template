export declare const NativeCookie: {
    clearAll: () => Promise<void>;
};
//# sourceMappingURL=cookie.d.ts.map