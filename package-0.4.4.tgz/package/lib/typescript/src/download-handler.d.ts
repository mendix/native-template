import { type DownloadConfig } from './specs/NativeMendixNative';
export declare const NativeDownloadHandler: {
    download: (url: string, downloadPath: string, config: DownloadConfig) => Promise<void>;
};
//# sourceMappingURL=download-handler.d.ts.map