import { type OtaDeployConfig, type OtaDownloadConfig } from './specs/NativeMendixNative';
export declare const NativeOta: {
    download: (config: OtaDownloadConfig) => Promise<import("./specs/NativeMendixNative").OtaDownloadResponse>;
    deploy: (config: OtaDeployConfig) => Promise<void>;
};
//# sourceMappingURL=ota.d.ts.map