export declare const NativeReloadHandler: {
    reload: () => Promise<void>;
    exitApp: () => Promise<void>;
};
//# sourceMappingURL=reload-handler.d.ts.map