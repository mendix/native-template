export declare const MxConfiguration: import("./specs/NativeMendixNative").Configuration;
//# sourceMappingURL=mx-configuration.d.ts.map