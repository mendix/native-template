export declare const AndroidNavigationBar: {
    height: number;
    isActive: boolean;
};
//# sourceMappingURL=navigation-mode.d.ts.map