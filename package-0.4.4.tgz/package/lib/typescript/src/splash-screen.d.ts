export declare const MendixSplashScreen: {
    show: () => void;
    hide: () => void;
};
//# sourceMappingURL=splash-screen.d.ts.map