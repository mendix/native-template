export declare const onReloadWithStateEvent: (handler: ($$PARAM_0$$: void) => void | Promise<void>) => import("react-native").EventSubscription;
export declare const onDownloadProgressEvent: (handler: ($$PARAM_0$$: import("./specs/NativeMendixNative").DownloadProgress) => void | Promise<void>) => import("react-native").EventSubscription;
//# sourceMappingURL=events.d.ts.map