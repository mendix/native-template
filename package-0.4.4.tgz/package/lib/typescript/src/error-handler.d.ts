export declare const NativeErrorHandler: {
    handle: (message: string, stackTrace: import("stacktrace-parser").StackFrame[]) => void;
};
//# sourceMappingURL=error-handler.d.ts.map