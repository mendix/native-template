//
//  NativeCookieModule.h
//  MendixNative
//
//  Created by Yogendra Shelke on 20/03/25.
//  Copyright © 2025 Mendix. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>

@interface NativeCookieModule : NSObject<RCTBridgeModule>
- (void) clearAll;
@end
