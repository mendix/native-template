#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SessionCookieStore : NSObject
+ (void)restore;
+ (void)persist;
+ (void)clear;
@end

NS_ASSUME_NONNULL_END
