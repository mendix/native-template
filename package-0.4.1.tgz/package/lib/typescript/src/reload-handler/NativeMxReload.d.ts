import { type TurboModule } from 'react-native';
import type { CodegenTypes } from 'react-native';
export interface Spec extends TurboModule {
    reload(): Promise<void>;
    exitApp(): Promise<void>;
    readonly onReloadWithState: CodegenTypes.EventEmitter<void>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeMxReload.d.ts.map