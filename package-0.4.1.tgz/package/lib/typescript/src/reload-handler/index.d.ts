export declare const NativeReloadHandler: {
    reload: () => Promise<void>;
    exitApp: () => Promise<void>;
};
//# sourceMappingURL=index.d.ts.map