import { type OtaDeployConfig, type OtaDownloadConfig } from './NativeMxOta';
export declare const NativeOta: {
    download: (config: OtaDownloadConfig) => Promise<import("./NativeMxOta").OtaDownloadResponse>;
    deploy: (config: OtaDeployConfig) => Promise<void>;
};
//# sourceMappingURL=index.d.ts.map