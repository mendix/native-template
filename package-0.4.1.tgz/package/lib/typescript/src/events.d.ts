export declare const onReloadWithStateEvent: import("react-native/types_generated/Libraries/Types/CodegenTypes").EventEmitter<void>;
export declare const onDownloadProgressEvent: import("react-native/types_generated/Libraries/Types/CodegenTypes").EventEmitter<import("./ota/NativeMxOta").DownloadProgress>;
//# sourceMappingURL=events.d.ts.map