import { type TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    show(): void;
    hide(): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeMxSplashScreen.d.ts.map