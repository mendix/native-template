export declare const NativeDownloadHandler: {
    download: (url: string, downloadPath: string, config: Record<string, any>) => Promise<void>;
};
//# sourceMappingURL=index.d.ts.map