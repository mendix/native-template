export declare const AndroidNavigationBar: {
    height: number;
    isActive: boolean;
};
//# sourceMappingURL=index.d.ts.map