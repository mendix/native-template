import { type TurboModule } from 'react-native';
import type { CodegenTypes } from 'react-native';
export interface Spec extends TurboModule {
    isNavigationBarActive(): boolean;
    getNavigationBarHeight(): CodegenTypes.Double;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeMxNavigation.d.ts.map